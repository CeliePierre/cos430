/**
 * File: SearchByArtistPrefix.java
 *****************************************************************************
 *                       Revision History
 *****************************************************************************
 * 9.2023 -Joel Kalala i created SearchByArtistPrefix
 * - I Created a dummy Song object with the artist prefix for binary search
 * - I used a combination of binary search and linear search
 * - I Calculated the total number of comparisons 
 * - I Calculated k, which is the number of songs with the artist prefix
 * - Calculate log base 2 of the total number of songs
 * - I added the  test method for this unit
 * 
 * 9.2023 -  @author Yusra Mugorewase 
 * - I Compare two Song objects based on their artist's name .
 * -I Compare the artist names of the two songs 
 * 
 * 8/2015 Anne Applin - Added formatting and JavaDoc
 * 2015 - Bob Boothe - starting code
 *****************************************************************************
 *
 */
package student;

import java.io.*;
import java.util.*;
import java.util.stream.Stream;

/**
 * Search by Artist Prefix searches the artists in the song database for artists
 * that begin with the input String
 *
 * @author Bob Booth
 */

public class SearchByArtistPrefix {

    // keep a local direct reference to the song array
    private final Song[] songs;

    /**
     * constructor initializes the property. [Done]
     * 
     * @param sc a SongCollection object
     */
    public SearchByArtistPrefix(SongCollection sc) {
        songs = sc.getAllSongs();
    }

    /**
     * find all songs matching artist prefix uses binary search should operate
     * in time log n + k (# matches) converts artistPrefix to lowercase and
     * creates a Song object with artist prefix as the artist in order to have a
     * Song to compare. walks back to find the first "beginsWith" match, then
     * walks forward adding to the arrayList until it finds the last match.
     *
     * @param artistPrefix all or part of the artist's name
     * @return an array of songs by artists with substrings that match the prefix
     *  @author Yusra Mugorewase
     * CmpArtist is a static nested class that implements the Comparator interface 
     * for comparing Song objects based on their artists.
     * The compare method increments the comparison count (cmpCnt) each time it's called. 
     * Then it compares two Song objects based on their artist names.   */
    
   public static class CmpArtist extends CmpCnt implements Comparator<Song> {
    @Override
    public int compare(Song s1, Song s2) {
        cmpCnt++; // Incrementing the comparison count.
        return s1.getArtist().compareToIgnoreCase(s2.getArtist());
        
    }
}
   

     /***
     * @search(String artistPrefix
     * @author kalalajoel
     *  This method is designed to search for songs by the artist's prefix
     * i Created a comparator object to compare Song objects by their artists
     * Reset the comparison count for this search
     * i Created a dummy Song object with the artist prefix for binary search
     * i Performed a binary search to find a potential match
     * i used a combination of binary search and linear search
     * If binarySearch returns a negative value, no exact match is found
     * First, the input string is transformed to lowercase.
     * Binary search is used to quickly find an approximate location of the matching artist
     * If the exact match is not found using binary search, it adjusts to the insertion point
     * Increment the additional comparison count
     * The method then iterates backward to find the starting point of the matching songs
     * Once the starting point is found, it iterates forward to collect all the matches
     * The method calculates the complexity of the search (comparisons used in binary search and the loops
     *  Calculate the total number of comparisons (binary search + additional)
     *  Calculate k, which is the number of songs with the artist prefix Output statistics
     * Calculate log base 2 of the total number of songs
     *  Calculate the theoretical complexity
     * It prints out various statistics and then returns an array of matching Song objects.
     */ 
 public Song[] search(String artistPrefix) {
    CmpArtist comparator = new CmpArtist();
    comparator.resetCmpCnt();

    Song dummy = new Song(artistPrefix, "", "");
    int foundIndex = Arrays.binarySearch(songs, dummy, comparator);
    int startIndex, endIndex;
    int additionalCmpCnt = 0;

    if (foundIndex < 0) {
        startIndex = -foundIndex - 1;
    } else {
        startIndex = foundIndex;
        while (startIndex - 1 >= 0 && songs[startIndex - 1].getArtist().equalsIgnoreCase(artistPrefix)) {
            startIndex--;
            additionalCmpCnt++;
        }
    }

    endIndex = startIndex;
    while (endIndex < songs.length && songs[endIndex].getArtist().toLowerCase().startsWith(artistPrefix.toLowerCase())) {
        endIndex++;
        additionalCmpCnt++;
    }

    int binarySearchComparisons = comparator.getCmpCnt();
    int totalComparisons = binarySearchComparisons + additionalCmpCnt;
    int k = endIndex - startIndex;

    System.out.println("index from binary search is: " + foundIndex);
    System.out.println("Binary search comparisons: " + binarySearchComparisons);
    if (foundIndex >= 0) {
        System.out.println("Front found at " + startIndex);
    }
    System.out.println("Comparisons to build the list: " + additionalCmpCnt);
    System.out.println("Actual complexity is: " + totalComparisons);
    System.out.println("k is " + k);
    int logN = (int) (Math.log(songs.length) / Math.log(2));
    System.out.println("log_2(n) = " + logN);
    int theoreticalComplexity = k + logN;
    System.out.println("Theoretical complexity k+log n is: " + theoreticalComplexity);

    return Arrays.copyOfRange(songs, startIndex, endIndex);
}
    /**
     * testing method for this unit
     *
     * @param args command line arguments set in Project Properties - the first
     * argument is the data file name and the second is the partial artist name,
     * e.g. be which should return beatles, beach boys, bee gees, etc.
     *  @author kalalajoel
     * The main method serves as the entry point of your program.
     * If no arguments are passed, it prints out an error message.
     * It constructs a SongCollection object with the song data from the given file.
     * Then, if a search string is provided, it searches for songs with artists that 
     * start with the given prefix using the search method.
     * It prints out the total number of matches found.
     * If there are matches, it prints out the first 10 matching songs. 
     * If not, it informs that no matches were found.
     */
  public static void main(String[] args) {
        if (args.length == 0) {
            System.err.println("usage: prog songfile [search string]");
            return;
        }

        SongCollection sc = new SongCollection(args[0]);
        //Song[] mysongs= sc.getAllSongs();
        
       // System.out.println(mysongs[1000].toString());
        
        SearchByArtistPrefix sbap = new SearchByArtistPrefix(sc);

        if (args.length > 1) {
            System.out.println("searching for: " + args[1]);
            Song[] byArtistResult = sbap.search(args[1]);

            System.out.println("Total matches: " + byArtistResult.length);

            if(byArtistResult.length > 0) {
                System.out.println("First 10 matches:");
                Stream.of(byArtistResult)
                      .limit(10)
                      .forEach(song -> System.out.println("Artist: " + song.getArtist() + ", Title: " + song.getTitle() + ", Lyrics: " + song.getLyrics())); 
            } else {
                System.out.println("No matches found.");
            }
        }
    }
}