
/**
 * File: SearchByArtistPrefix.java
 *****************************************************************************
 *                       Revision History
 *****************************************************************************
 * 9.2023 -Joel Kalala i created SearchByArtistPrefix
 * - I Created a dummy Song object with the artist prefix for binary search
 * - I used a combination of binary search and linear search
 * - I Calculated the total number of comparisons
 * - I Calculated k, which is the number of songs with the artist prefix
 * - Calculate log base 2 of the total number of songs
 * - I added the  test method for this unit
 *
 * 9.2023 -  @author Yusra Mugorewase
 * - I Compare two Song objects based on their artist's name .
 * -I Compare the artist names of the two songs
 * -Created an object to count comparisons and reset its counter
 *
 * 8/2015 Anne Applin - Added formatting and JavaDoc
 * 2015 - Bob Boothe - starting code
 *****************************************************************************
 *
 */
package student;

import java.io.*;
import java.util.*;
import java.util.stream.Stream;

/**
 * Search by Artist Prefix searches the artists in the song database for artists
 * that begin with the input String
 *
 * @author Bob Booth
 */
/**
 * raList: This is an instance of the RaggedArrayList class that will store the
 * songs. titleComparator: This is a comparator used to compare Song objects
 * based on their titles. totalComparisonsForFullRAList: This stores the total
 * number of comparisons made when constructing the RaggedArrayList.
 */
public class SearchByTitlePrefix {

    private RaggedArrayList<Song> raList;
    private Comparator<Song> titleComparator;
    private int totalComparisonsForFullRAList;

    public SearchByTitlePrefix(SongCollection sc) {
        this.raList = new RaggedArrayList<>(new Song.CmpTitle());
        this.titleComparator = new Song.CmpTitle();

        Song[] songs = sc.getAllSongs();
        for (Song s : songs) {
            raList.add(s);
        }
        //raList.stats();

        this.totalComparisonsForFullRAList = raList.getSublistComparisons();
    }

    @Override
    public String toString() {
        return "Total comparisons to build the Full RaggedArrayList: " + totalComparisonsForFullRAList;
    }

    /**
     * When an instance of SearchByTitlePrefix is created, it takes a
     * SongCollection object as an argument. This collection is then used to
     * populate the RaggedArrayList. The total comparisons made during the
     * addition are stored.
     */
    public Song[] search(String titlePrefix) {
          if (titleComparator instanceof TitleComparator) {
        ((TitleComparator) titleComparator).resetCmpCnt(); // Reset count here.
    }

    String nextPrefix = titlePrefix.substring(0, titlePrefix.length() - 1)
            + (char) (titlePrefix.charAt(titlePrefix.length() - 1) + 1);

    Song fromDummy = new Song("dummy", titlePrefix, "dummy");
    Song toDummy = new Song("dummy", nextPrefix, "dummy");

    RaggedArrayList<Song> resultRAList = raList.subList(fromDummy, toDummy); // This should use the comparator and thus increment the count.
    
    int totalComparisons = getSearchComparisons(); // Retrieve count after subList.
    System.out.println("Total comparisons to build the sublist: " + totalComparisons);

    resultRAList.stats(); // This just outputs the stats for the sublist.

    return resultRAList.toArray(new Song[resultRAList.size()]);
}

    /**
     * This method allows you to search for songs by title prefix. It creates
     * two dummy songs with titles representing the start and end points of the
     * search range. Using these two dummy songs, it retrieves a sublist of
     * matching songs from the main raList.
     */
    private class TitleComparator implements Comparator<Song> {

        private int cmpCnt = 0;

        @Override
        public int compare(Song song1, Song song2) {
            cmpCnt++;
            String title1 = song1.getTitle().toLowerCase();
            String title2 = song2.getTitle().toLowerCase();
            return title1.compareTo(title2);
        }

        public int getCmpCnt() {
            return cmpCnt;
        }

        public void resetCmpCnt() {
            this.cmpCnt = 0;
        }

    }

    public int getListSize() {
        return raList.size();  // Assuming RaggedArrayList has a getSize() method
    }

    public RaggedArrayList<Song> getRAList() {
        return this.raList; // Assuming raList is the name of the underlying RaggedArrayList in the SearchByTitlePrefix class.
    }

    public int getSearchComparisons() {
        if (titleComparator instanceof TitleComparator) {
            return ((TitleComparator) titleComparator).getCmpCnt();
        }
        return -1; // or throw an exception or handle this case as you deem fit.
    }

    /**
     * Create an instance of SongCollection using a given song file (this is
     * assumed to have already been implemented elsewhere and will be loaded via
     * command-line arguments). Create an instance of SearchByTitlePrefix using
     * the SongCollection instance. Use the search method on the
     * SearchByTitlePrefix instance to perform the
     */
    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Usage: java SearchByTitlePrefix <song_file>");
            return;
        }

        String songFile = args[0];
        SongCollection songCollection = new SongCollection(songFile);
        SearchByTitlePrefix searchByTitle = new SearchByTitlePrefix(songCollection);

        // Print comparison for Full RaggedArrayList
        System.out.println("Comparison to build the Full RaggedArrayList = " + searchByTitle.totalComparisonsForFullRAList);

        // Display stats for the RaggedArrayList
        RaggedArrayList<Song> raList = searchByTitle.getRAList();
        raList.stats();

        // Calculate and display the square root of N for the entire RaggedArrayList
        int fullListSize = searchByTitle.getListSize();
        double sqrtFullListSize = Math.sqrt(fullListSize);
        System.out.printf("Square root of  N: %.2f\n", sqrtFullListSize);
        String[] prefixes = {"search", "Angel", "T"};
        int[] expectedMatches = {2, 23, 1148};

        for (int i = 0; i < prefixes.length; i++) {
            System.out.println("\nSearching for: " + prefixes[i]);
            Song[] matchingSongs = searchByTitle.search(prefixes[i]);
            System.out.println("Total matches for \"" + prefixes[i] + "\": " + matchingSongs.length);
            System.out.printf("Square root of N for \"%s\": %.2f\n", prefixes[i], Math.sqrt(matchingSongs.length));

            // Printing the total comparisons during the search for each prefix
            System.out.println("Total comparisons during search for \"" + prefixes[i] + "\": " + searchByTitle.getSearchComparisons());

            if (matchingSongs.length != expectedMatches[i]) {
                System.out.println("Mismatch! Expected: " + expectedMatches[i] + ", but got: " + matchingSongs.length);
            }
        }
    }
}
