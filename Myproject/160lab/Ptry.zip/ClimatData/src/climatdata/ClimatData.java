package climatdata;

import java.util.Arrays;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.ArrayList;

/**
 *
 * @author kalalajoel
 */
public class ClimatData {

private DailyReading[] readings;
private double averageMaxTemp;
private double averageMinTemp;
private int[] yearStartingIndexes;

public void readFile(String fileName) {
     try {
            Scanner inFile = new Scanner(new FileReader(fileName));
            if (!inFile.hasNext()) {
                System.err.println("File" + fileName + "is empty.");
                System.exit(3);
                
            
         
              
                
            } 
            int number =inFile.nextInt();
            readings = new DailyReading[number];
            inFile.nextLine();
            inFile.nextLine();
            inFile.nextLine();
            inFile.useDelimiter("[/ \t\n\r]+");
            int i =0;
            while (inFile.hasNextLine()) {
                // read the line and split on the comma
                int month= inFile.nextInt();
                int day = inFile.nextInt();
                int years =inFile.nextInt();
                int maxTemp = inFile.nextInt();
                int minTemp =inFile.nextInt();
               Date dat= new Date(month, day, years);
               DailyReading read= new DailyReading(dat,maxTemp,minTemp);
               readings [i] = read;
               i++;
            }
            } catch (FileNotFoundException e) {
            System.err.println("File " + fileName + " not found.");
            System.exit(1);
        } catch (InputMismatchException e) {
            System.err.println("File " + fileName + " is not in the correct format.");
            System.exit(2);
        } catch (NoSuchElementException e) {
            System.err.println("File " + fileName + " is not in the correct format.");
            System.exit(2);
        }
}
//metheode get maxTemp
public int getMaxTemp() {
    int maxTemp = 0;
    int index=0;
    for (int i = 0; i < readings.length; i++) {
        if (readings[i].getmaxTemp()>= maxTemp) {
            maxTemp = readings[i].getmaxTemp();
            index=i;
        }
    }
    return index;
}
//metheode get minTemp
public int getMinTemp() {
    int minTemp = 0;
    int index=0;
    for (int i = 0; i < readings.length; i++) {
        if (readings[i].getminTemp()<=minTemp) {
            minTemp = readings[i].getminTemp();
            index=i;
        }
    }
    return index;
}
//metheode get averageMaxTemp
public double getAverageMaxTemp() {
    double averageMaxTemp = 0;
    int sum = 0;
    int count = 0;
    for (int i = 0; i < readings.length; i++) {
        
            sum += readings[i].getmaxTemp();
            count++;
        }
    
    averageMaxTemp = sum / count;
    return averageMaxTemp;
}

                

public double getAverageMinTemp() {
    double averageMinTemp = 0;
    int sum= 0;
    int count=0;
    for (int i = 0; i < readings.length; i++) {
        
        sum += readings[i].getminTemp();
            count++;
    }
    averageMinTemp = sum / count;
    return averageMinTemp;
}

//metheode get yearStartingIndexes
public int[] getYearStartingIndexes() {
    int[] yearStartingIndexes = new int[readings.length];
    int count = 0;
    for (int i = 0; i < readings.length; i++) {
        if (readings[i].getDate().getMonth() == 1 && readings[i].getDate().getDay() == 1) {
            yearStartingIndexes[count] = i;
            count++;
        }
    }
    return yearStartingIndexes;
}
//metheode get yearStartingIndexes
public int[] getYearStartingIndexes(int year) {
    int[] yearStartingIndexes = new int[readings.length];
    int count = 0;
    for (int i = 0; i < readings.length; i++) {
        if (readings[i].getDate().getMonth() == 1 && readings[i].getDate().getDay() == 1 && readings[i].getDate().getYear() == year) {
            yearStartingIndexes[count] = i;
            count++;
        }
    }
    return yearStartingIndexes;
}

//metheode get yearStartingIndexes
public int[] getYearStartingIndexes(Date startDate, Date endDate) {
    int[] yearStartingIndexes = new int[readings.length];
    int count = 0;
    for (int i = 0; i < readings.length; i++) {
        if (readings[i].getDate().getMonth() == 1 && readings[i].getDate().getDay() == 1 && readings[i].getDate().getYear() >= startDate.getYear() && readings[i].getDate().getYear() <= endDate.getYear()) {
            yearStartingIndexes[count] = i;
            count++;
        }
    }
    return yearStartingIndexes;
}
}
                
                
    
                
    /** try {
        FileReader fr = new FileReader(fileName);
        BufferedReader br = new BufferedReader(fr);
        String line = br.readLine();
        int numOfLines = Integer.parseInt(line);
        readings = new DailyReading[numOfLines];
        int i = 0;
        while ((line = br.readLine()) != null) {
            String[] parts = line.split(" ");
            int year = Integer.parseInt(parts[0]);
            int month = Integer.parseInt(parts[1]);
            int day = Integer.parseInt(parts[2]);
            double maxTemp = Double.parseDouble(parts[3]);
            double minTemp = Double.parseDouble(parts[4]);
            readings[i] = new DailyReading(year, month, day, maxTemp, minTemp);
            i++;
        }
        br.close();
    } catch (IOException e) {
        System.out.println("Error reading file: " + fileName);
    }
}*/

