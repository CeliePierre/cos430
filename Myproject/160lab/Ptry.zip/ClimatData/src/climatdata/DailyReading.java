package climatdata;

/**
 *
 * @author kalalajoel
 */
public class DailyReading {

    Date Joe;
    int maxTemp;
    int minTemp;

    DailyReading(Date Joe, int maxTemp, int minTemp) {

        this.Joe = Joe;
        this.maxTemp = maxTemp;
        this.minTemp = minTemp;

    }

    Date getDate() {
        return Joe;
    }

    int getmaxTemp() {
        return maxTemp;

    }

    int getminTemp() {
        return minTemp;
    }

    @Override
    public String toString() {
        return String.format("%s %6d %6d",Joe.toString(),maxTemp,minTemp);
    }
}
