/**
 * File: SearchByArtistPrefix.java
 *****************************************************************************
 *                       Revision History
 *****************************************************************************
 * 9.2023 -Joel Kalala i created SearchByArtistPrefix
 * - I Created a dummy Song object with the artist prefix for binary search
 * - I used a combination of binary search and linear search
 * - I Calculated the total number of comparisons
 * - I Calculated k, which is the number of songs with the artist prefix
 * - Calculate log base 2 of the total number of songs
 * - I added the  test method for this unit
 *
 * 9.2023 -  @author Yusra Mugorewase
 * - I Compare two Song objects based on their artist's name .
 * -I Compare the artist names of the two songs
 * -Created an object to count comparisons and reset its counter
 *
 * 8/2015 Anne Applin - Added formatting and JavaDoc
 * 2015 - Bob Boothe - starting code
 *****************************************************************************
 *
 */
package student;

import java.io.*;
import java.util.*;
import java.util.stream.Stream;

/**
 * Search by Artist Prefix searches the artists in the song database for artists
 * that begin with the input String
 *
 * @author Bob Booth
 */
/**
 * raList: This is an instance of the RaggedArrayList class that will store the
 * songs. titleComparator: This is a comparator used to compare Song objects
 * based on their titles. totalComparisonsForFullRAList: This stores the total
 * number of comparisons made when constructing the RaggedArrayList.
 */
public class SearchByTitlePrefix {

   // private RaggedArrayList<Song> raList;
    //private Comparator<Song> titleComparator;
   // private int totalComparisonsForFullRAList;
   // private Comparator<Song> cmp = new Song.CmpTitle();
        private RaggedArrayList<Song> raList;
    private Comparator<Song> cmp;
 
  
    

     public SearchByTitlePrefix(SongCollection sc) {
        Song[] songs = sc.getAllSongs();
      cmp = new Song.CmpTitle(); // This line should be inside the constructor.
        raList = new RaggedArrayList<>(cmp);
        raList = new RaggedArrayList(cmp);
        System.out.println("Comparison to build the Full RaggedArrayList = " + ((CmpCnt) cmp).getCmpCnt());
        raList.stats();
        // ... rest of the constructor code
    }
     

        
    /**
     * When an instance of SearchByTitlePrefix is created, it takes a
     * SongCollection object as an argument. This collection is then used to
     * populate the RaggedArrayList. The total comparisons made during the
     * addition are stored.
     */
    public Song[] search(String titlePrefix) {

   titlePrefix = titlePrefix.toLowerCase();
    Song first = new Song("dummy", titlePrefix, "dummy");
    System.out.println("The song with the prefix: " + first);

    if(cmp instanceof CmpCnt) {
        ((CmpCnt)cmp).resetCmpCnt(); // Correct the case and ensure your cmp implements CmpCnt
    }

    int tpLength = titlePrefix.length();
    char ch = titlePrefix.charAt(tpLength - 1);
    ch = (char) (ch + 1);
    String endString = titlePrefix.substring(0, tpLength - 1) + ch;
    Song last = new Song("dummy", endString, "dummy");
    System.out.println("The song for the end of the subList: " + last);

    RaggedArrayList<Song> res = raList.subList(first, last);
    System.out.println("Comparisons to build the sublist: " + ((CmpCnt)cmp).getCmpCnt());

    Song[] result = res.toArray(new Song[res.size()]);
    return result;
}

    public static void main(String[] args) {
        if (args.length == 0) {
            System.err.println("usage: prog songfile [search string]");
            return;
        }

        SongCollection sc = new SongCollection(args[0]);
        //Song[] mysongs= sc.getAllSongs();

        // System.out.println(mysongs[1000].toString());
        SearchByTitlePrefix  sbap = new SearchByTitlePrefix (sc);

        if (args.length > 1) {
            System.out.println("searching for: " + args[1]);
            Song[] byArtistResult = sbap.search(args[1]);

            System.out.println("Total matches: " + byArtistResult.length);

            if (byArtistResult.length > 0) {
                System.out.println("First 10 matches:");
                Stream.of(byArtistResult)
                        .limit(10)
                        .forEach(song -> System.out.println("Artist: " + song.getArtist() + ", Title: " + song.getTitle() + ", Lyrics: " + song.getLyrics()));
            } else {
                System.out.println("No matches found.");
            }
        }
    }
}
