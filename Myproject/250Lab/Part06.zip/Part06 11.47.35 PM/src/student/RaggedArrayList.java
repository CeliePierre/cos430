/**
 * File: RaggedArrayList.java
 * ****************************************************************************
 *                           Revision History
 * ****************************************************************************
 * 10/2023 - I Used the findFront() method to locate the item.
 * If the found location's item matches the target item, return true.
 * I Implemented an iterator over the RaggedArrayList.
 * The iterator has more items as long as the current L2Array is not null
 * and the current position within it is less than the number of used items.
 * I Removed operation is not supported in this iterator.
 * Copies the elements of the RaggedArrayList into the provided array.
 * I Created a sublist of the RaggedArrayList ranging from fromElement (inclusive)
 * to toElement (exclusive).
 * 10/2023 - Milo Keys - cleaned up and added author ship to methods
 * - cleaned up moveToNext
 *
 *
 * 8/2015 - Anne Applin - Added formatting and JavaDoc
 * 2015 - Bob Boothe - starting code
 * ****************************************************************************
 */
package student;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Scanner;

/**
 * *
 * The RaggedArrayList is a 2 level data structure that is an array of arrays.
 *
 * It keeps the items in sorted order according to the comparator. Duplicates
 * are allowed. New items are added after any equivalent items.
 *
 * NOTE: normally fields, internal nested classes and non API methods should all
 * be private, however they have been made public so that the tester code can
 * set them
 *
 * @author Bob Booth
 * @param <E> A generic data type so that this structure can be built with any
 * data type (object)
 */
public class RaggedArrayList<E> implements Iterable<E> {

    // must be even so when split get two equal pieces
    private static final int MINIMUM_SIZE = 4;
    private int sublistComparisons = 0;
    public int size;

    public Object[] l1Array;
    public int l1NumUsed;
    private Comparator<E> comp;

    public RaggedArrayList(Comparator<E> c) {
        size = 0;
        // you can't create an array of a generic type
        l1Array = new Object[MINIMUM_SIZE];
        // first 2nd level array
        l1Array[0] = new L2Array(MINIMUM_SIZE);
        l1NumUsed = 1;
        comp = c;
    }

    public class L2Array {

        /**
         * the array of items
         */
        public E[] items;
        /**
         * number of items in this L2Array with values
         */
        public int numUsed;

        public L2Array(int capacity) {
            // you can't create an array of a generic type
            items = (E[]) new Object[capacity];
            numUsed = 0;
        }
    }

    public int size() {
        return size;
    }

    public void clear() {
        size = 0;
        // clear all but first l2 array
        Arrays.fill(l1Array, 1, l1Array.length, null);
        l1NumUsed = 1;
        L2Array l2Array = (L2Array) l1Array[0];
        // clear out l2array
        Arrays.fill(l2Array.items, 0, l2Array.numUsed, null);
        l2Array.numUsed = 0;
    }

    public class ListLoc {

        public int level1Index;

        /**
         * Level 2 index
         */
        public int level2Index;

        public ListLoc(int level1Index, int level2Index) {
            this.level1Index = level1Index;
            this.level2Index = level2Index;
        }

        /**
         * test if two ListLoc's are to the same location (done -- do not
         * change)
         *
         * @param otherObj the other listLoc
         * @return true if they are the same location and false otherwise
         */
        public boolean equals(Object otherObj) {
            // not really needed since it will be ListLoc
            if (getClass() != otherObj.getClass()) {
                return false;
            }
            ListLoc other = (ListLoc) otherObj;

            return level1Index == other.level1Index
                    && level2Index == other.level2Index;
        }

        public void moveToNext() {
            // TO DO IN PART 5 and NOT BEFORE
            L2Array currentL2 = (L2Array) l1Array[level1Index];

            // Check if we've moved beyond the current L2Array.
            if (level2Index + 1 > currentL2.numUsed - 1) {
                // Reset level2Index.
                level2Index = 0;

                // Move to the next L2Array within the l1Array.
                level1Index++;

                // If we've moved beyond the boundaries of the l1Array, reset to valid boundaries.
                if (level1Index > l1NumUsed - 1) {
                    level1Index = l1NumUsed - 1;
                    currentL2 = (L2Array) l1Array[level1Index];
                    level2Index = currentL2.numUsed; // Point to one past the last valid position.
                }
            } else {
                // Move to the next item within the current L2Array.
                level2Index++;
            }
        }
    }
public ListLoc findFront(E item) {
    int i1 = 0;
    int i2 = 0;

    if (size > 0) {
        L2Array l2Array = (L2Array) l1Array[i1];

        // Search l1Array. This loop iterates through the outer array.
        while (i1 < l1NumUsed - 1 && comp.compare(item, l2Array.items[l2Array.numUsed - 1]) > 0) {
            sublistComparisons++;  // Increment here
            i1++;
            l2Array = (L2Array) l1Array[i1];
        }

        // Search within l2Array. This loop iterates through the inner array.
        while (i2 < l2Array.numUsed && comp.compare(l2Array.items[i2], item) < 0) {
            sublistComparisons++;  // Increment here
            i2++;
        }

        if (i1 > 0 && i2 == 0 && comp.compare(l2Array.items[i2], item) > 0) {
            sublistComparisons++;  // Increment here
            i1--;
            i2 = ((L2Array) l1Array[i1]).numUsed;
        }
    }
    return new ListLoc(i1, i2);
}

public ListLoc findEnd(E item) {
    int i1 = 0;
    int i2 = 0;

    if (size > 0) {
        while (i1 < l1Array.length && l1Array[i1] != null) {
            sublistComparisons++;  // Increment here
            if (comp.compare(((L2Array) l1Array[i1]).items[0], item) <= 0) {
                i1++;
            } else {
                break;
            }
        }

        if (i1 > 0) {
            i1--;
        }

        L2Array l2Array = (L2Array) l1Array[i1];
        while ((l2Array != null && i2 < l2Array.numUsed)) {
            sublistComparisons++;  // Increment here
            if (comp.compare(item, l2Array.items[i2]) >= 0) {
                i2++;
            } else {
                break;
            }
        }
    }
    return new ListLoc(i1, i2);
}

    public boolean add(E item) {
        ListLoc location = findEnd(item);
        L2Array currentL2 = (L2Array) l1Array[location.level1Index];

        //inserts item into the correct location
        System.arraycopy(currentL2.items, location.level2Index, currentL2.items, location.level2Index + 1, currentL2.numUsed - location.level2Index); //Shifts
        currentL2.items[location.level2Index] = item; //actually inserts item
        currentL2.numUsed++;
        size++;

        //Did that make L2 become full?
        if (currentL2.numUsed < currentL2.items.length) { //l2 did not become full 
            return true;
        } else {
            //if it becomes full then split it or double it
            if (currentL2.items.length < l1Array.length) { //Double it
                currentL2.items = Arrays.copyOf(currentL2.items, currentL2.items.length * 2);
            } else { //Split
                L2Array temp = new L2Array(currentL2.items.length); // Create a temp array to hold data
                System.arraycopy(currentL2.items, currentL2.items.length / 2, temp.items, 0, currentL2.items.length / 2);
                Arrays.fill(currentL2.items, currentL2.numUsed / 2, currentL2.numUsed, null);
                currentL2.numUsed = currentL2.items.length / 2; // Update numUsed
                temp.numUsed = currentL2.items.length / 2;
                System.arraycopy(l1Array, location.level1Index + 1, l1Array, location.level1Index + 2, l1NumUsed - (location.level1Index + 1));
                l1Array[location.level1Index + 1] = temp;
                l1NumUsed++;

                // If l1 became full, double its size
                if (l1Array.length == l1NumUsed) {
                    l1Array = Arrays.copyOf(l1Array, l1Array.length * 2);
                }
            }
        }

        return true;
    }

    public boolean contains(E item) {
        // TO DO in part 5 and NOT BEFORE
        ListLoc location = findFront(item);

        L2Array l2Array = (L2Array) l1Array[location.level1Index];

        if (location.level2Index < l2Array.numUsed && comp.compare(item, l2Array.items[location.level2Index]) == 0) {
            return true;
        }

        return false;
    }

    public E[] toArray(E[] a) {
        // TO DO in part 5 and NOT BEFORE
        if (a.length < size) {
            throw new IllegalArgumentException("Provided array is too small");
        }

        int count = 0;
        for (int i = 0; i < l1NumUsed; i++) {
            L2Array l2Array = (L2Array) l1Array[i];
            for (int j = 0; j < l2Array.numUsed; j++) {
                a[count++] = l2Array.items[j];
            }
        }

        if (a.length > size) {
            a[size] = null; // Set the element immediately following the end of the list to null.
        }

        return a;
    }

    public RaggedArrayList<E> subList(E fromElement, E toElement) {
        // TO DO in part 5 and NOT BEFORE

        RaggedArrayList<E> result = new RaggedArrayList<E>(comp);

        ListLoc startLoc = findFront(fromElement);
        ListLoc endLoc = findFront(toElement);

        while (!startLoc.equals(endLoc)) {
            L2Array currentL2 = (L2Array) l1Array[startLoc.level1Index];
            result.add(currentL2.items[startLoc.level2Index]);
            startLoc.moveToNext();
        }

        return result;
    }

    public int getSublistComparisons() {
        return sublistComparisons;
    }

    public Iterator<E> iterator() {
        return new Itr();
    }

    private class Itr implements Iterator<E> {

        private ListLoc loc;

        /*
         * create iterator at start of list
         * (DONE)
         */
        Itr() {
            loc = new ListLoc(0, 0);
        }

        @Override
        public boolean hasNext() {
            // TO DO in part 5 and NOT BEFORE
            return loc.level1Index < l1NumUsed && loc.level2Index < ((L2Array) l1Array[loc.level1Index]).numUsed;
        }

        @Override
        public E next() {
            // TO DO in part 5 and NOT BEFORE
            if (!hasNext()) {
                throw new NoSuchElementException();
            }

            E item = ((L2Array) l1Array[loc.level1Index]).items[loc.level2Index];
            loc.moveToNext();

            return item;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }

    }

    public int computeLevel1Usage() {
        return 0;
    }

    public void stats() {
        System.out.println("STATS:");
        int size = this.size();
        System.out.println("list size N = " + size);

        // level 1 array
        int l1NumUsed = this.l1NumUsed;
        System.out.println("level 1 array " + l1NumUsed + " of "
                + this.l1Array.length + " used.");

        // level 2 arrays
        int minL2size = Integer.MAX_VALUE, maxL2size = 0;
        for (int i1 = 0; i1 < this.l1NumUsed; i1++) {
            RaggedArrayList<Song>.L2Array l2array
                    = (RaggedArrayList<Song>.L2Array) (this.l1Array[i1]);
            minL2size = Math.min(minL2size, l2array.numUsed);
            maxL2size = Math.max(maxL2size, l2array.numUsed);
        }
        System.out.printf("level 2 array sizes: min = %d used, avg = %.1f "
                + "used, max = %d used.%n%n",
                minL2size,
                (double) size / l1NumUsed, maxL2size);
    }

}
